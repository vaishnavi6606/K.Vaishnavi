# Attendence_management_system

A Flutter project.

## Getting Started

This project was a joint effort by a group of eight individuals from numerous domains, and it was developed for university usage. 
This github repo is just for demonstration purposes. 

My role as a mobile app development lead on this project was to keep the work flow going as needed, create the app as quickly as feasible and as efficiently as possible, manage the team we had on hand, as well as avoid conflicts and misunderstandings. 

To move our project ahead, we utilised the following technologies.
  1. Flutter / Dart
  2. Mongodb
  3. Reactjs
  4. Nodejs
  5. Figma
  6. Expressjs
  7. Rest API 

## Following are the screenshots of some of the screens!
![Simulator Screen Shot - iPhone 13 Pro Max - 2022-04-19 at 00 09 31](https://user-images.githubusercontent.com/56469253/163857920-6fc26d24-bf29-4343-a5ea-1a031aea6b2d.png)
![Simulator Screen Shot - iPhone 13 Pro Max - 2022-04-19 at 00 09 38](https://user-images.githubusercontent.com/56469253/163857912-571d1ce6-84aa-47f1-85b0-9ea03e606d95.png)
![Simulator Screen Shot - iPhone 13 Pro Max - 2022-04-19 at 00 09 42](https://user-images.githubusercontent.com/56469253/163857902-633e8715-3310-40be-80d4-61197a8d3023.png)
![Simulator Screen Shot - iPhone 13 Pro Max - 2022-04-19 at 00 09 52](https://user-images.githubusercontent.com/56469253/163857888-50404bf1-19d8-44bc-be86-aba42ea026e2.png)
![Simulator Screen Shot - iPhone 13 Pro Max - 2022-04-19 at 00 09 54](https://user-images.githubusercontent.com/56469253/163857877-4abec470-6519-4312-8a3b-1258173622cf.png)
![Simulator Screen Shot - iPhone 13 Pro Max - 2022-04-19 at 00 10 01](https://user-images.githubusercontent.com/56469253/163857870-e8a7fffb-0a97-4ea0-9b1d-2f6358226caa.png)
![Simulator Screen Shot - iPhone 13 Pro Max - 2022-04-19 at 00 10 05](https://user-images.githubusercontent.com/56469253/163857864-6995935f-7812-4dc2-8b63-c3109dad9cf9.png)
[Simulator Screen Shot - iPhone 13 Pro Max - 2022-04-19 at 00 10 26](https://user-images.githubusercontent.com/56469253/163857847-d3f8940b-f68e-4f68-a031-9cb8960e3af3.png)
