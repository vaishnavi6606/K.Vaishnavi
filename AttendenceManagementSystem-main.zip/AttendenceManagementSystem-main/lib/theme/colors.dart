import 'package:flutter/material.dart';

// const primaryColor =const Color(0xffde0000);
const primaryColor = Colors.red;
const red = const Color(0xffff0800);
const green = const Color(0xff00CE2D); // Second `const` is optional in assignments.
const yellow = const Color(0xffffc100);