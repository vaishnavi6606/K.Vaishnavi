import 'package:flutter/material.dart';

// Text
const Color textPrimary = Color(0xFF111111);
const Color textSecondary = Color(0xFF3A3A3A);
